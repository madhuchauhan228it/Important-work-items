package com.sunglowsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunitProgramsApplicationTests {

	@Test
	void contextLoads() {
	}

}
